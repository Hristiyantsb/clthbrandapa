"use client"

import { useState } from "react"
import OnboardingScreen from "@/components/onboarding-screen"
import Dashboard from "@/components/dashboard"
import ResourceLibrary from "@/components/resource-library"
import BrandBuilder from "@/components/brand-builder"
import TodoList from "@/components/todo-list"
import Community from "@/components/community"
import MobileLayout from "@/components/mobile-layout"
import Navigation from "@/components/navigation"

export default function Home() {
  const [currentScreen, setCurrentScreen] = useState("onboarding")

  const renderScreen = () => {
    switch (currentScreen) {
      case "onboarding":
        return <OnboardingScreen onComplete={() => setCurrentScreen("dashboard")} />
      case "dashboard":
        return <Dashboard />
      case "resources":
        return <ResourceLibrary />
      case "brand":
        return <BrandBuilder />
      case "todo":
        return <TodoList />
      case "community":
        return <Community />
      default:
        return <Dashboard />
    }
  }

  return (
    <div className="flex items-center justify-center min-h-screen bg-gray-100 p-4">
      <MobileLayout>
        {renderScreen()}
        {currentScreen !== "onboarding" && (
          <Navigation currentScreen={currentScreen} setCurrentScreen={setCurrentScreen} />
        )}
      </MobileLayout>
    </div>
  )
}
