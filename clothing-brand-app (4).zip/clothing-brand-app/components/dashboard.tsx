import { CheckCircle, Circle } from "lucide-react"
import { Progress } from "@/components/ui/progress"

export default function Dashboard() {
  const steps = [
    { id: 1, title: "Brand Basics", completed: true },
    { id: 2, title: "Visual Identity", completed: true },
    { id: 3, title: "Business Plan", completed: false },
    { id: 4, title: "Manufacturing", completed: false },
    { id: 5, title: "Marketing Strategy", completed: false },
    { id: 6, title: "Launch Preparation", completed: false },
  ]

  const completedSteps = steps.filter((step) => step.completed).length
  const progress = (completedSteps / steps.length) * 100

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-2">Welcome back!</h1>
      <p className="text-gray-600 mb-6">Continue building your clothing brand</p>

      <div className="bg-purple-50 rounded-xl p-4 mb-6">
        <div className="flex justify-between items-center mb-2">
          <h2 className="font-medium">Your Progress</h2>
          <span className="text-sm text-purple-600 font-medium">
            {completedSteps}/{steps.length} Steps
          </span>
        </div>
        <Progress value={progress} className="h-2 mb-4" />

        <div className="space-y-3">
          {steps.map((step) => (
            <div key={step.id} className="flex items-center">
              {step.completed ? (
                <CheckCircle className="h-5 w-5 text-purple-600 mr-3" />
              ) : (
                <Circle className="h-5 w-5 text-gray-300 mr-3" />
              )}
              <span className={step.completed ? "text-gray-800" : "text-gray-500"}>{step.title}</span>
            </div>
          ))}
        </div>
      </div>

      <h2 className="font-medium mb-3">Continue where you left off</h2>
      <div className="bg-white border border-gray-100 rounded-xl p-4 mb-6 shadow-sm">
        <h3 className="font-medium mb-1">Business Plan</h3>
        <p className="text-sm text-gray-500 mb-3">Complete your business plan to move forward</p>
        <div className="flex justify-between items-center">
          <Progress value={30} className="h-2 w-3/4" />
          <span className="text-xs text-gray-500">30%</span>
        </div>
      </div>

      <h2 className="font-medium mb-3">Recent Resources</h2>
      <div className="space-y-3">
        <div className="bg-white border border-gray-100 rounded-xl p-4 flex items-center shadow-sm">
          <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center mr-3">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="20"
              height="20"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="text-blue-600"
            >
              <path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z" />
              <polyline points="14 2 14 8 20 8" />
            </svg>
          </div>
          <div>
            <h3 className="font-medium text-sm">How to Find Manufacturers</h3>
            <p className="text-xs text-gray-500">Guide • 10 min read</p>
          </div>
        </div>

        <div className="bg-white border border-gray-100 rounded-xl p-4 flex items-center shadow-sm">
          <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center mr-3">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="20"
              height="20"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="text-green-600"
            >
              <path d="m21.44 11.05-9.19 9.19a6 6 0 0 1-8.49-8.49l8.57-8.57A4 4 0 1 1 18 8.84l-8.59 8.57a2 2 0 0 1-2.83-2.83l8.49-8.48" />
            </svg>
          </div>
          <div>
            <h3 className="font-medium text-sm">Pricing Strategy for Clothing</h3>
            <p className="text-xs text-gray-500">Template • 5 min read</p>
          </div>
        </div>
      </div>
    </div>
  )
}
