"use client"

import { ArrowRight } from "lucide-react"
import { Button } from "@/components/ui/button"

interface OnboardingScreenProps {
  onComplete: () => void
}

export default function OnboardingScreen({ onComplete }: OnboardingScreenProps) {
  return (
    <div className="flex flex-col items-center justify-center h-full px-6 text-center">
      <div className="w-32 h-32 bg-purple-100 rounded-full flex items-center justify-center mb-8">
        <svg
          xmlns="http://www.w3.org/2000/svg"
          width="64"
          height="64"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
          className="text-purple-600"
        >
          <path d="M20.38 3.46 16 2a4 4 0 0 1-8 0L3.62 3.46a2 2 0 0 0-1.34 2.23l.58 3.47a1 1 0 0 0 .99.84H6v10c0 1.1.9 2 2 2h8a2 2 0 0 0 2-2V10h2.15a1 1 0 0 0 .99-.84l.58-3.47a2 2 0 0 0-1.34-2.23z" />
        </svg>
      </div>
      <h1 className="text-3xl font-bold mb-4">Welcome to Threadly</h1>
      <p className="text-gray-600 mb-8">
        Your personal guide to creating and launching your own clothing brand. We'll help you every step of the way.
      </p>
      <div className="space-y-4 w-full">
        <div className="flex items-center p-4 bg-purple-50 rounded-xl">
          <div className="w-10 h-10 bg-purple-100 rounded-full flex items-center justify-center mr-4">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="20"
              height="20"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="text-purple-600"
            >
              <path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z" />
              <path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z" />
            </svg>
          </div>
          <div className="text-left">
            <h3 className="font-medium">Learn</h3>
            <p className="text-sm text-gray-500">Access guides and resources</p>
          </div>
        </div>

        <div className="flex items-center p-4 bg-purple-50 rounded-xl">
          <div className="w-10 h-10 bg-purple-100 rounded-full flex items-center justify-center mr-4">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="20"
              height="20"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="text-purple-600"
            >
              <path d="M12 20a8 8 0 1 0 0-16 8 8 0 0 0 0 16Z" />
              <path d="M12 14a2 2 0 1 0 0-4 2 2 0 0 0 0 4Z" />
              <path d="M12 2v2" />
              <path d="M12 22v-2" />
              <path d="m17 20.66-1-1.73" />
              <path d="M11 10.27 7 3.34" />
              <path d="m20.66 17-1.73-1" />
              <path d="m3.34 7 1.73 1" />
              <path d="M14 12h8" />
              <path d="M2 12h2" />
              <path d="m20.66 7-1.73 1" />
              <path d="m3.34 17 1.73-1" />
              <path d="m17 3.34-1 1.73" />
              <path d="m7 20.66-1-1.73" />
            </svg>
          </div>
          <div className="text-left">
            <h3 className="font-medium">Create</h3>
            <p className="text-sm text-gray-500">Build your brand identity</p>
          </div>
        </div>

        <div className="flex items-center p-4 bg-purple-50 rounded-xl">
          <div className="w-10 h-10 bg-purple-100 rounded-full flex items-center justify-center mr-4">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="20"
              height="20"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="text-purple-600"
            >
              <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14" />
              <polyline points="22 4 12 14.01 9 11.01" />
            </svg>
          </div>
          <div className="text-left">
            <h3 className="font-medium">Launch</h3>
            <p className="text-sm text-gray-500">Take your brand to market</p>
          </div>
        </div>
      </div>
      <Button className="mt-8 w-full bg-purple-600 hover:bg-purple-700 text-white" onClick={onComplete}>
        Get Started <ArrowRight className="ml-2 h-4 w-4" />
      </Button>
    </div>
  )
}
