"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Upload, Plus } from "lucide-react"

export default function BrandBuilder() {
  const [brandStyle, setBrandStyle] = useState("streetwear")

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-2">Brand Builder</h1>
      <p className="text-gray-600 mb-6">Define your brand's identity and vision</p>

      <div className="space-y-6">
        <div>
          <Label htmlFor="brand-name" className="block mb-2 text-sm font-medium">
            Brand Name
          </Label>
          <Input id="brand-name" placeholder="Enter your brand name" className="bg-gray-50 border-gray-100" />
        </div>

        <div>
          <Label htmlFor="mission" className="block mb-2 text-sm font-medium">
            Mission Statement
          </Label>
          <Textarea
            id="mission"
            placeholder="What is your brand's purpose?"
            className="bg-gray-50 border-gray-100 min-h-[100px]"
          />
        </div>

        <div>
          <Label className="block mb-2 text-sm font-medium">Brand Style</Label>
          <RadioGroup value={brandStyle} onValueChange={setBrandStyle} className="grid grid-cols-2 gap-2">
            <div
              className={`border rounded-xl p-3 flex flex-col items-center ${
                brandStyle === "streetwear" ? "border-purple-600 bg-purple-50" : "border-gray-100"
              }`}
            >
              <RadioGroupItem value="streetwear" id="streetwear" className="sr-only" />
              <Label htmlFor="streetwear" className="cursor-pointer text-center">
                <div className="w-12 h-12 bg-gray-100 rounded-full mb-2 flex items-center justify-center">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className={brandStyle === "streetwear" ? "text-purple-600" : "text-gray-400"}
                  >
                    <path d="M20.38 3.46 16 2a4 4 0 0 1-8 0L3.62 3.46a2 2 0 0 0-1.34 2.23l.58 3.47a1 1 0 0 0 .99.84H6v10c0 1.1.9 2 2 2h8a2 2 0 0 0 2-2V10h2.15a1 1 0 0 0 .99-.84l.58-3.47a2 2 0 0 0-1.34-2.23z" />
                  </svg>
                </div>
                <span className="text-sm font-medium">Streetwear</span>
              </Label>
            </div>

            <div
              className={`border rounded-xl p-3 flex flex-col items-center ${
                brandStyle === "luxury" ? "border-purple-600 bg-purple-50" : "border-gray-100"
              }`}
            >
              <RadioGroupItem value="luxury" id="luxury" className="sr-only" />
              <Label htmlFor="luxury" className="cursor-pointer text-center">
                <div className="w-12 h-12 bg-gray-100 rounded-full mb-2 flex items-center justify-center">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className={brandStyle === "luxury" ? "text-purple-600" : "text-gray-400"}
                  >
                    <path d="M6 9H4.5a2.5 2.5 0 0 1 0-5H6" />
                    <path d="M18 9h1.5a2.5 2.5 0 0 0 0-5H18" />
                    <path d="M4 22h16" />
                    <path d="M10 14.66V17c0 .55-.47.98-.97 1.21C7.85 18.75 7 20.24 7 22" />
                    <path d="M14 14.66V17c0 .55.47.98.97 1.21C16.15 18.75 17 20.24 17 22" />
                    <path d="M18 2H6v7a6 6 0 0 0 12 0V2Z" />
                  </svg>
                </div>
                <span className="text-sm font-medium">Luxury</span>
              </Label>
            </div>

            <div
              className={`border rounded-xl p-3 flex flex-col items-center ${
                brandStyle === "casual" ? "border-purple-600 bg-purple-50" : "border-gray-100"
              }`}
            >
              <RadioGroupItem value="casual" id="casual" className="sr-only" />
              <Label htmlFor="casual" className="cursor-pointer text-center">
                <div className="w-12 h-12 bg-gray-100 rounded-full mb-2 flex items-center justify-center">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className={brandStyle === "casual" ? "text-purple-600" : "text-gray-400"}
                  >
                    <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z" />
                    <polyline points="9 22 9 12 15 12 15 22" />
                  </svg>
                </div>
                <span className="text-sm font-medium">Casual</span>
              </Label>
            </div>

            <div
              className={`border rounded-xl p-3 flex flex-col items-center ${
                brandStyle === "athletic" ? "border-purple-600 bg-purple-50" : "border-gray-100"
              }`}
            >
              <RadioGroupItem value="athletic" id="athletic" className="sr-only" />
              <Label htmlFor="athletic" className="cursor-pointer text-center">
                <div className="w-12 h-12 bg-gray-100 rounded-full mb-2 flex items-center justify-center">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className={brandStyle === "athletic" ? "text-purple-600" : "text-gray-400"}
                  >
                    <path d="M18 8c0 2.2-1.8 4-4 4s-4-1.8-4-4 1.8-4 4-4 4 1.8 4 4z" />
                    <path d="m17 17 4 4" />
                    <path d="M3 14c0 2.2 1.8 4 4 4s4-1.8 4-4-1.8-4-4-4-4 1.8-4 4z" />
                    <path d="M7 10v4" />
                    <path d="M14 10v4" />
                  </svg>
                </div>
                <span className="text-sm font-medium">Athletic</span>
              </Label>
            </div>
          </RadioGroup>
        </div>

        <div>
          <Label className="block mb-2 text-sm font-medium">Mood Board</Label>
          <p className="text-xs text-gray-500 mb-3">Upload images that represent your brand's aesthetic</p>

          <div className="grid grid-cols-3 gap-2 mb-2">
            <div className="aspect-square bg-gray-50 rounded-lg border border-gray-100 flex items-center justify-center">
              <img
                src="/placeholder.svg?height=80&width=80"
                alt="Mood board"
                className="w-full h-full object-cover rounded-lg"
              />
            </div>
            <div className="aspect-square bg-gray-50 rounded-lg border border-gray-100 flex items-center justify-center">
              <img
                src="/placeholder.svg?height=80&width=80"
                alt="Mood board"
                className="w-full h-full object-cover rounded-lg"
              />
            </div>
            <div className="aspect-square bg-gray-50 rounded-lg border border-dashed border-gray-200 flex flex-col items-center justify-center text-gray-400">
              <Upload className="h-5 w-5 mb-1" />
              <span className="text-xs">Add</span>
            </div>
          </div>
        </div>

        <div>
          <Label className="block mb-2 text-sm font-medium">Color Palette</Label>
          <div className="flex space-x-2 mb-2">
            <div className="w-8 h-8 rounded-full bg-purple-500 border-2 border-white shadow-sm"></div>
            <div className="w-8 h-8 rounded-full bg-indigo-400 border-2 border-white shadow-sm"></div>
            <div className="w-8 h-8 rounded-full bg-pink-300 border-2 border-white shadow-sm"></div>
            <div className="w-8 h-8 rounded-full bg-gray-200 border-2 border-white shadow-sm flex items-center justify-center">
              <Plus className="h-4 w-4 text-gray-500" />
            </div>
          </div>
        </div>

        <Button className="w-full bg-purple-600 hover:bg-purple-700">Save Brand Profile</Button>
      </div>
    </div>
  )
}
