"use client"

import { useState } from "react"
import { Check, Plus, Clock } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function TodoList() {
  const [tasks, setTasks] = useState([
    { id: 1, title: "Register business name", completed: true, deadline: "Completed", category: "business" },
    { id: 2, title: "Create logo design brief", completed: true, deadline: "Completed", category: "design" },
    { id: 3, title: "Research manufacturers", completed: false, deadline: "Due Jun 10", category: "manufacturing" },
    { id: 4, title: "Finalize brand color palette", completed: false, deadline: "Due Jun 12", category: "design" },
    { id: 5, title: "Draft business plan", completed: false, deadline: "Due Jun 15", category: "business" },
    { id: 6, title: "Create social media accounts", completed: false, deadline: "Due Jun 20", category: "marketing" },
  ])

  const toggleTask = (id: number) => {
    setTasks(tasks.map((task) => (task.id === id ? { ...task, completed: !task.completed } : task)))
  }

  const completedTasks = tasks.filter((task) => task.completed).length
  const progress = (completedTasks / tasks.length) * 100

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-2">To-Do List</h1>
      <p className="text-gray-600 mb-4">Track your progress and manage tasks</p>

      <div className="bg-purple-50 rounded-xl p-4 mb-6">
        <div className="flex justify-between items-center mb-2">
          <h2 className="font-medium">Overall Progress</h2>
          <span className="text-sm text-purple-600 font-medium">
            {completedTasks}/{tasks.length} Tasks
          </span>
        </div>
        <Progress value={progress} className="h-2" />
      </div>

      <Tabs defaultValue="all" className="mb-6">
        <TabsList className="grid grid-cols-4 mb-4">
          <TabsTrigger value="all">All</TabsTrigger>
          <TabsTrigger value="business">Business</TabsTrigger>
          <TabsTrigger value="design">Design</TabsTrigger>
          <TabsTrigger value="marketing">Marketing</TabsTrigger>
        </TabsList>

        <TabsContent value="all" className="space-y-3">
          {tasks.map((task) => (
            <div
              key={task.id}
              className={`flex items-center p-4 rounded-xl border ${
                task.completed ? "bg-gray-50 border-gray-100" : "bg-white border-gray-100"
              }`}
            >
              <button
                onClick={() => toggleTask(task.id)}
                className={`w-6 h-6 rounded-full flex items-center justify-center mr-3 ${
                  task.completed ? "bg-purple-600" : "border-2 border-gray-200"
                }`}
              >
                {task.completed && <Check className="h-4 w-4 text-white" />}
              </button>
              <div className="flex-1">
                <h3 className={`font-medium ${task.completed ? "text-gray-400 line-through" : ""}`}>{task.title}</h3>
                <div className="flex items-center text-xs text-gray-500 mt-1">
                  {task.completed ? (
                    <Check className="h-3 w-3 mr-1 text-green-500" />
                  ) : (
                    <Clock className="h-3 w-3 mr-1" />
                  )}
                  <span>{task.deadline}</span>
                </div>
              </div>
              <div
                className={`px-2 py-1 rounded-full text-xs ${
                  task.category === "business"
                    ? "bg-blue-100 text-blue-600"
                    : task.category === "design"
                      ? "bg-purple-100 text-purple-600"
                      : task.category === "manufacturing"
                        ? "bg-orange-100 text-orange-600"
                        : "bg-green-100 text-green-600"
                }`}
              >
                {task.category}
              </div>
            </div>
          ))}
        </TabsContent>

        <TabsContent value="business" className="space-y-3">
          {tasks
            .filter((task) => task.category === "business")
            .map((task) => (
              <div
                key={task.id}
                className={`flex items-center p-4 rounded-xl border ${
                  task.completed ? "bg-gray-50 border-gray-100" : "bg-white border-gray-100"
                }`}
              >
                <button
                  onClick={() => toggleTask(task.id)}
                  className={`w-6 h-6 rounded-full flex items-center justify-center mr-3 ${
                    task.completed ? "bg-purple-600" : "border-2 border-gray-200"
                  }`}
                >
                  {task.completed && <Check className="h-4 w-4 text-white" />}
                </button>
                <div className="flex-1">
                  <h3 className={`font-medium ${task.completed ? "text-gray-400 line-through" : ""}`}>{task.title}</h3>
                  <div className="flex items-center text-xs text-gray-500 mt-1">
                    {task.completed ? (
                      <Check className="h-3 w-3 mr-1 text-green-500" />
                    ) : (
                      <Clock className="h-3 w-3 mr-1" />
                    )}
                    <span>{task.deadline}</span>
                  </div>
                </div>
                <div className="px-2 py-1 rounded-full text-xs bg-blue-100 text-blue-600">{task.category}</div>
              </div>
            ))}
        </TabsContent>

        <TabsContent value="design" className="space-y-3">
          {tasks
            .filter((task) => task.category === "design")
            .map((task) => (
              <div
                key={task.id}
                className={`flex items-center p-4 rounded-xl border ${
                  task.completed ? "bg-gray-50 border-gray-100" : "bg-white border-gray-100"
                }`}
              >
                <button
                  onClick={() => toggleTask(task.id)}
                  className={`w-6 h-6 rounded-full flex items-center justify-center mr-3 ${
                    task.completed ? "bg-purple-600" : "border-2 border-gray-200"
                  }`}
                >
                  {task.completed && <Check className="h-4 w-4 text-white" />}
                </button>
                <div className="flex-1">
                  <h3 className={`font-medium ${task.completed ? "text-gray-400 line-through" : ""}`}>{task.title}</h3>
                  <div className="flex items-center text-xs text-gray-500 mt-1">
                    {task.completed ? (
                      <Check className="h-3 w-3 mr-1 text-green-500" />
                    ) : (
                      <Clock className="h-3 w-3 mr-1" />
                    )}
                    <span>{task.deadline}</span>
                  </div>
                </div>
                <div className="px-2 py-1 rounded-full text-xs bg-purple-100 text-purple-600">{task.category}</div>
              </div>
            ))}
        </TabsContent>

        <TabsContent value="marketing" className="space-y-3">
          {tasks
            .filter((task) => task.category === "marketing")
            .map((task) => (
              <div
                key={task.id}
                className={`flex items-center p-4 rounded-xl border ${
                  task.completed ? "bg-gray-50 border-gray-100" : "bg-white border-gray-100"
                }`}
              >
                <button
                  onClick={() => toggleTask(task.id)}
                  className={`w-6 h-6 rounded-full flex items-center justify-center mr-3 ${
                    task.completed ? "bg-purple-600" : "border-2 border-gray-200"
                  }`}
                >
                  {task.completed && <Check className="h-4 w-4 text-white" />}
                </button>
                <div className="flex-1">
                  <h3 className={`font-medium ${task.completed ? "text-gray-400 line-through" : ""}`}>{task.title}</h3>
                  <div className="flex items-center text-xs text-gray-500 mt-1">
                    {task.completed ? (
                      <Check className="h-3 w-3 mr-1 text-green-500" />
                    ) : (
                      <Clock className="h-3 w-3 mr-1" />
                    )}
                    <span>{task.deadline}</span>
                  </div>
                </div>
                <div className="px-2 py-1 rounded-full text-xs bg-green-100 text-green-600">{task.category}</div>
              </div>
            ))}
        </TabsContent>
      </Tabs>

      <Button className="w-full flex items-center justify-center gap-2 bg-purple-600 hover:bg-purple-700">
        <Plus className="h-4 w-4" /> Add New Task
      </Button>
    </div>
  )
}
